-- Drift & Time Attack Voting App Database Schema
-- Execute this SQL in Supabase SQL Editor

-- Drop existing tables if they exist (in reverse order of dependencies)
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS app_settings CASCADE;
DROP TABLE IF EXISTS driver_applications CASCADE;
DROP TABLE IF EXISTS warnings CASCADE;
DROP TABLE IF EXISTS sessions CASCADE;
DROP TABLE IF EXISTS votes CASCADE;
DROP TABLE IF EXISTS cars CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Create users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(50) DEFAULT 'user' CHECK (role IN ('user', 'driver', 'flag_manager', 'kaczka')),
    vote_weight INTEGER DEFAULT 1,
    skill_level VARCHAR(50) CHECK (skill_level IN ('basic', 'medium', 'advanced')),
    has_voted BOOLEAN DEFAULT FALSE,
    is_ready BOOLEAN DEFAULT FALSE,
    instagram_username VARCHAR(100),
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create cars table
CREATE TABLE cars (
    id SERIAL PRIMARY KEY,
    registration_number VARCHAR(20) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('drift', 'time_attack')),
    image_url TEXT,
    description TEXT,
    driver_id INTEGER REFERENCES users(id),
    votes_count INTEGER DEFAULT 0,
    total_points INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create votes table
CREATE TABLE votes (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) NOT NULL,
    car_id INTEGER REFERENCES cars(id) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('drift', 'time_attack')),
    vote_weight INTEGER DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, category)
);

-- Create vote cancellations table
CREATE TABLE vote_cancellations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('drift', 'time_attack')),
    cancelled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, category)
);

-- Create sessions table for track management
CREATE TABLE sessions (
    id SERIAL PRIMARY KEY,
    group_name VARCHAR(50) NOT NULL CHECK (group_name IN ('basic', 'medium', 'advanced')),
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    pause_start TIMESTAMP WITH TIME ZONE,
    pause_end TIMESTAMP WITH TIME ZONE,
    total_pause_duration BIGINT DEFAULT 0, -- Total pause time in milliseconds
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'paused', 'completed')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create warnings table
CREATE TABLE warnings (
    id SERIAL PRIMARY KEY,
    driver_id INTEGER REFERENCES users(id) NOT NULL,
    reason TEXT NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    issued_by INTEGER REFERENCES users(id),
    is_read BOOLEAN DEFAULT FALSE
);

-- Create driver applications table
CREATE TABLE driver_applications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) NOT NULL,
    registration_number VARCHAR(20) NOT NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL CHECK (category IN ('drift', 'time_attack')),
    skill_level VARCHAR(50) NOT NULL CHECK (skill_level IN ('basic', 'medium', 'advanced')),
    description TEXT,
    image_url TEXT,
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create notifications table
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) NOT NULL,
    type VARCHAR(50) NOT NULL CHECK (type IN ('vote_received', 'vote_summary', 'application_approved', 'application_rejected', 'warning')),
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create app settings table
CREATE TABLE app_settings (
    id SERIAL PRIMARY KEY,
    logo_url TEXT,
    app_name VARCHAR(255) DEFAULT 'CARSWAG',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert kaczka user
INSERT INTO users (name, email, role, vote_weight) 
VALUES ('Kaczka', 'kaczka@drift.com', 'kaczka', 10);

-- Create some sample data for testing
INSERT INTO users (name, email, role, vote_weight, skill_level) VALUES 
('Jan Kowalski', 'jan@example.com', 'driver', 5, 'medium'),
('Anna Nowak', 'anna@example.com', 'driver', 5, 'basic'),
('Piotr Wiśniewski', 'piotr@example.com', 'user', 1, NULL),
('Kierownik Flag', 'flags@drift.com', 'flag_manager', 1, NULL);

-- Insert sample cars
INSERT INTO cars (registration_number, brand, model, category, driver_id, votes_count, total_points) VALUES 
('KR 12345', 'Toyota', 'Supra', 'drift', 2, 15, 75),
('WA 67890', 'Nissan', 'Silvia S15', 'drift', 3, 12, 60),
('GD 11111', 'BMW', 'E36', 'time_attack', 2, 18, 90),
('PO 22222', 'Honda', 'Civic Type R', 'time_attack', 3, 10, 50);

-- Create function to update vote counts and send notifications
CREATE OR REPLACE FUNCTION update_vote_counts()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql AS $$
DECLARE
    car_owner_id INTEGER;
    voter_name VARCHAR(255);
    car_info VARCHAR(255);
BEGIN
    -- Update votes_count and total_points for the car
    UPDATE cars 
    SET 
        votes_count = (SELECT COUNT(*) FROM votes WHERE car_id = NEW.car_id),
        total_points = (SELECT COALESCE(SUM(vote_weight), 0) FROM votes WHERE car_id = NEW.car_id)
    WHERE id = NEW.car_id;
    
    -- Mark user as voted
    UPDATE users SET has_voted = TRUE WHERE id = NEW.user_id;
    
    -- Get car owner and voter info for notification
    SELECT driver_id, CONCAT(brand, ' ', model) INTO car_owner_id, car_info
    FROM cars WHERE id = NEW.car_id;
    
    SELECT name INTO voter_name FROM users WHERE id = NEW.user_id;
    
    -- Send notification to car owner (only if not voting for own car)
    IF car_owner_id IS NOT NULL AND car_owner_id != NEW.user_id THEN
        INSERT INTO notifications (user_id, type, message, is_read)
        VALUES (
            car_owner_id,
            'vote_received',
            CONCAT(voter_name, ' zagłosował na Twoje auto: ', car_info),
            FALSE
        );
    END IF;
    
    RETURN NEW;
END;
$$;

-- Create trigger for vote counting
CREATE TRIGGER trigger_update_vote_counts
    AFTER INSERT ON votes
    FOR EACH ROW
    EXECUTE FUNCTION update_vote_counts();

-- Enable Row Level Security (RLS)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE cars ENABLE ROW LEVEL SECURITY;
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE vote_cancellations ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE warnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE driver_applications ENABLE ROW LEVEL SECURITY;

-- SECURE RLS POLICIES - Restricted access based on user roles and ownership

-- USERS table policies
CREATE POLICY "Users can read basic info" ON users FOR SELECT USING (
    -- Allow reading basic user info (name, avatar) but not sensitive data like email
    true
);

CREATE POLICY "Users can insert own profile" ON users FOR INSERT WITH CHECK (
    -- Allow creating new user profiles
    true
);

CREATE POLICY "Users can update own profile" ON users FOR UPDATE USING (
    -- Users can only update their own profile, admins can update anyone
    auth.uid()::text = id::text OR 
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can delete users" ON users FOR DELETE USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

-- CARS table policies  
CREATE POLICY "Cars are publicly readable" ON cars FOR SELECT USING (true);

CREATE POLICY "Drivers can manage own cars" ON cars FOR INSERT WITH CHECK (
    driver_id::text = auth.uid()::text OR
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Drivers can update own cars" ON cars FOR UPDATE USING (
    driver_id::text = auth.uid()::text OR
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can delete cars" ON cars FOR DELETE USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

-- VOTES table policies
CREATE POLICY "Votes are publicly readable" ON votes FOR SELECT USING (true);

CREATE POLICY "Users can vote" ON votes FOR INSERT WITH CHECK (
    user_id::text = auth.uid()::text
);

CREATE POLICY "Users can delete own votes" ON votes FOR DELETE USING (
    user_id::text = auth.uid()::text
);

-- VOTE_CANCELLATIONS table policies
CREATE POLICY "Vote cancellations readable" ON vote_cancellations FOR SELECT USING (true);

CREATE POLICY "Users can cancel own votes" ON vote_cancellations FOR INSERT WITH CHECK (
    user_id::text = auth.uid()::text
);

-- SESSIONS table policies
CREATE POLICY "Sessions are publicly readable" ON sessions FOR SELECT USING (true);

CREATE POLICY "Only admins can manage sessions" ON sessions FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can update sessions" ON sessions FOR UPDATE USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can delete sessions" ON sessions FOR DELETE USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

-- WARNINGS table policies
CREATE POLICY "Users can read own warnings" ON warnings FOR SELECT USING (
    user_id::text = auth.uid()::text OR
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can create warnings" ON warnings FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Users can update own warnings" ON warnings FOR UPDATE USING (
    user_id::text = auth.uid()::text OR
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

-- NOTIFICATIONS table policies
CREATE POLICY "Users can read own notifications" ON notifications FOR SELECT USING (
    user_id::text = auth.uid()::text OR
    user_id IS NULL OR -- Global notifications
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can create notifications" ON notifications FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Users can update own notifications" ON notifications FOR UPDATE USING (
    user_id::text = auth.uid()::text OR
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Users can delete own notifications" ON notifications FOR DELETE USING (
    user_id::text = auth.uid()::text OR
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

-- APP_SETTINGS table policies
CREATE POLICY "App settings are publicly readable" ON app_settings FOR SELECT USING (true);

CREATE POLICY "Only admins can modify app settings" ON app_settings FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Only admins can update app settings" ON app_settings FOR UPDATE USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

-- DRIVER_APPLICATIONS table policies
CREATE POLICY "Admins can read all applications" ON driver_applications FOR SELECT USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);

CREATE POLICY "Users can submit applications" ON driver_applications FOR INSERT WITH CHECK (true);

CREATE POLICY "Only admins can update applications" ON driver_applications FOR UPDATE USING (
    EXISTS (SELECT 1 FROM users WHERE id::text = auth.uid()::text AND role = 'admin')
);
