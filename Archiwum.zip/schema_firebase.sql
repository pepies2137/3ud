-- Dodatkowe tabele dla integracji Firebase Cloud Messaging

-- Tabela do przechowywania tokenów FCM użytkowników
CREATE TABLE IF NOT EXISTS user_fcm_tokens (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    fcm_token TEXT NOT NULL,
    device_info JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    UNIQUE(user_id, fcm_token)
);

-- Indeksy dla wydajności
CREATE INDEX IF NOT EXISTS idx_user_fcm_tokens_user_id ON user_fcm_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_user_fcm_tokens_active ON user_fcm_tokens(is_active);
CREATE INDEX IF NOT EXISTS idx_user_fcm_tokens_updated ON user_fcm_tokens(updated_at);

-- Tabela do logowania wysłanych powiadomień FCM
CREATE TABLE IF NOT EXISTS fcm_notification_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    fcm_token TEXT,
    notification_type VARCHAR(50) NOT NULL,
    title TEXT,
    body TEXT,
    data JSONB DEFAULT '{}',
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, failed, delivered
    error_message TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivered_at TIMESTAMP,
    clicked_at TIMESTAMP
);

-- Indeksy dla logów FCM
CREATE INDEX IF NOT EXISTS idx_fcm_logs_user_id ON fcm_notification_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_fcm_logs_type ON fcm_notification_logs(notification_type);
CREATE INDEX IF NOT EXISTS idx_fcm_logs_status ON fcm_notification_logs(status);
CREATE INDEX IF NOT EXISTS idx_fcm_logs_sent_at ON fcm_notification_logs(sent_at);

-- Funkcja do czyszczenia starych tokenów FCM
CREATE OR REPLACE FUNCTION cleanup_old_fcm_tokens()
RETURNS void AS $$
BEGIN
    -- Usuń tokeny starsze niż 90 dni
    DELETE FROM user_fcm_tokens 
    WHERE updated_at < NOW() - INTERVAL '90 days';
    
    -- Usuń logi starsze niż 30 dni
    DELETE FROM fcm_notification_logs 
    WHERE sent_at < NOW() - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- Trigger do automatycznego ustawiania updated_at
CREATE OR REPLACE FUNCTION update_fcm_token_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_fcm_token_timestamp
    BEFORE UPDATE ON user_fcm_tokens
    FOR EACH ROW
    EXECUTE FUNCTION update_fcm_token_timestamp();

-- Komentarze dla dokumentacji
COMMENT ON TABLE user_fcm_tokens IS 'Przechowuje tokeny Firebase Cloud Messaging dla każdego użytkownika';
COMMENT ON TABLE fcm_notification_logs IS 'Logi wysłanych powiadomień FCM dla analityki i debugowania';
COMMENT ON FUNCTION cleanup_old_fcm_tokens() IS 'Czyści stare tokeny FCM i logi (uruchamiać cyklicznie)';